#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char **argv)
{
    FILE *fp=fopen("emp.txt","r");
    int n;
    char tmp[256]={0x0};
    printf("#####	List des client   #####\n\n");
    while(fp && fgets(tmp, sizeof(tmp), fp))
    {
        if (strstr(tmp, "Nom") || strstr(tmp, "Prenom"))
            printf("%s", tmp);

    }
    if(fp) fclose(fp);
    choix:
    printf("Pour retourner au menu Tapez 1:\n");
    scanf("%d",&n);
	if(n==1)
	{
	system("cls");
	system("Menu.exe");
	}else
	system("cls");
	system("AfficherClient.exe");
}
