#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct client
{
int id;
char Nom[20];
char Prenom[20];
char adresse[20];
int cin;
} client;//structure client

typedef struct compte
{
int idCompte;
float solde ;
}compte;//structure compte


int main()
{
    FILE *fptr;
    FILE *co;
    char  c;
    int n,i; 
	client cl;
	compte cpt;

    fptr = fopen("emp.txt", "a");//saisir dans le fichier
 
    if (fptr == NULL)
    {
        printf("File does not exists \n");
        return 0;
    }
    i=0;

    do{
    printf("#####  AJOUT DE CLIENT  #####\n");
    	printf("Entrer le nom : \n"); //Nom
    scanf("%s", cl.Nom);
    	co = fopen("emp.txt", "r");// lire le fichier
  			while ((c = fgetc(co)) != EOF)
			{ 
     			if (c == '\n')
   		 		i++;// Compter les lignes
    		}
   		fclose(co);
	cl.id=i/6; // retourne le placement de l'id du client
    fprintf(fptr, "%d-Nom    = %s\n", cl.id,cl.Nom);
    
   		printf("Entrer le prenom : \n");  //Prenom
	scanf("%s", cl.Prenom);
    fprintf(fptr, "-Prenom     = %s\n",cl.Prenom);

    	printf("Adresse : \n"); //adresse
    scanf("%s", cl.adresse);
    fprintf(fptr, "-Adresse     = %s\n",cl.adresse);

    	printf("CIN : \n"); //cin
    scanf("%d", &cl.cin);
    fprintf(fptr, "-CIN     = %d\n", cl.cin);

    	printf("IdCompte : \n"); //Idcompte
    scanf("%d", &cpt.idCompte);
    fprintf(fptr, "-IdCompte    = %d\n", cpt.idCompte);

    	printf("Entrer le solde : \n"); //solde
    scanf("%f", &cpt.solde);
    fprintf(fptr, "-Solde  = %.2f,\n", cpt.solde);

    printf("Voulez vous ajouter un autre client: 1: Oui / 0: Non\n");
    scanf("%d",&n);
    printf("\n\n");
	}while(n!=0);

    fclose(fptr);
    	// return to mainmenu
	if(n==0)
	{
	system("cls");
	system("cls");
	system("Menu.exe");
	}
}
