#include<stdio.h>
#include<stdlib.h>
#include<string.h>




int main(){
	int n;
	
	printf("\t\t\t\t\t############### MAIN MENU ###############\n");
	printf("\t\t\t\t\t#\t\t\t\t\t#\n");
	printf("\t\t\t\t\t#\tAjout client..........1\t\t#\n");
	printf("\t\t\t\t\t#\t\t\t\t\t#\n");
	printf("\t\t\t\t\t#\tAfficher la liste ....2\t\t#\n");
	printf("\t\t\t\t\t#\t\t\t\t\t#\n");
	printf("\t\t\t\t\t#\tListe detailer........3\t\t#\n");
	printf("\t\t\t\t\t#\t\t\t\t\t#\n");
	printf("\t\t\t\t\t#\tQuitter...............4\t\t#\n");
	printf("\t\t\t\t\t#\t\t\t\t\t#\n");
	printf("\t\t\t\t\t#########################################\n");
	printf("\t\t\t\t\t\t    Votre choix :");
	scanf("%d",&n);
	printf("\n");
	printf("\n");
	if(n==1){
	system("Ajoutclient.exe");
	}
	else if(n==2){
	system("AfficherClient.exe");
	}
	else if(n==3){
	system("RechercheClient.exe");
	}else if(n==4){
	return 0;	
	}else {
	system("cls");
	system("Menu.exe");
	}   	
}
